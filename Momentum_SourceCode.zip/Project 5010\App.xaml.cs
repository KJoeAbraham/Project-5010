﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace Project_5010
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
