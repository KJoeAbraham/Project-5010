using Project_5010.Models;
using Project_5010.Services;
using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace Project_5010.Views
{
    public partial class GoalsView : UserControl
    {
        private readonly FoodFileService _foodService;
        private UserSettings _settings;
        private readonly ObservableCollection<FoodEntryViewModel> _todayItems = new();

        public GoalsView(UserSettings settings, FoodFileService foodService)
        {
            InitializeComponent();
            _settings = settings;
            _foodService = foodService;

            TodayDateText.Text = DateTime.Today.ToString("dddd, MMMM d, yyyy");
            FoodListView.ItemsSource = _todayItems;

            Refresh();
        }

        public void ApplyUserSettings(UserSettings settings)
        {
            _settings = settings;
            RefreshCalorieCard();
        }

        public void RefreshFood()
        {
            Refresh();
        }

        private void Refresh()
        {
            _todayItems.Clear();
            var all = _foodService.Load();
            foreach (var entry in all.Where(f => f.Date.Date == DateTime.Today))
                _todayItems.Add(new FoodEntryViewModel(entry));

            RefreshCalorieCard();
            TotalConsumedText.Text = _todayItems.Sum(f => f.Calories) + " kcal";
        }

        private void RefreshCalorieCard()
        {
            bool hasProfile = _settings.Age > 0 && _settings.WeightKg > 0 && _settings.HeightCm > 0;

            if (!hasProfile)
            {
                SetupPromptBorder.Visibility = Visibility.Visible;
                GoalKcalText.Text = "\u2014";
                RemainingKcalText.Text = "\u2014";
                GoalStatusText.Text = "Set up your profile in Settings.";
                GoalStatusText.Foreground = new SolidColorBrush(Color.FromRgb(0x92, 0x40, 0x0E));
                CalorieProgressFill.Width = 0;
                return;
            }

            SetupPromptBorder.Visibility = Visibility.Collapsed;

            int goal = CalorieCalculator.CalculateDailyGoal(
                _settings.WeightKg, _settings.HeightCm, _settings.Age,
                _settings.Sex, _settings.ActivityLevel, _settings.GoalType);

            int consumed = _todayItems.Sum(f => f.Calories);
            int remaining = goal - consumed;

            GoalKcalText.Text = goal.ToString();
            ConsumedKcalText.Text = consumed.ToString();
            GoalSubtitleText.Text = $"Mifflin-St Jeor \u00b7 {_settings.GoalType} \u00b7 {_settings.ActivityLevel}";

            // Update the track width after layout - use a dispatcher call
            Dispatcher.BeginInvoke(System.Windows.Threading.DispatcherPriority.Loaded, new Action(() =>
            {
                double trackWidth = ((Border)CalorieProgressFill.Parent).ActualWidth;
                double percent = Math.Min(1.0, trackWidth > 0 ? (double)consumed / goal : 0);
                CalorieProgressFill.Width = trackWidth * percent;
            }));

            if (consumed > goal)
            {
                RemainingKcalText.Text = (consumed - goal).ToString();
                RemainingLabelText.Text = "kcal over";
                RemainingBorder.Background = new SolidColorBrush(Color.FromRgb(0xFE, 0xF2, 0xF2));
                RemainingKcalText.Foreground = new SolidColorBrush(Color.FromRgb(0xEF, 0x44, 0x44));
                CalorieProgressFill.Background = new SolidColorBrush(Color.FromRgb(0xEF, 0x44, 0x44));
                GoalStatusText.Text = $"\u26a0\ufe0f  Over by {consumed - goal} kcal today.";
                GoalStatusText.Foreground = new SolidColorBrush(Color.FromRgb(0xEF, 0x44, 0x44));
            }
            else
            {
                RemainingKcalText.Text = remaining.ToString();
                RemainingLabelText.Text = "kcal left";
                RemainingBorder.Background = new SolidColorBrush(Color.FromRgb(0xF0, 0xFD, 0xF4));
                RemainingKcalText.Foreground = new SolidColorBrush(Color.FromRgb(0x10, 0xB9, 0x81));
                CalorieProgressFill.Background = new SolidColorBrush(Color.FromRgb(0x6D, 0x4A, 0xFF));
                GoalStatusText.Text = consumed == 0
                    ? $"Start logging food to track your {goal} kcal goal."
                    : $"\u2705  {remaining} kcal remaining today. Keep it up!";
                GoalStatusText.Foreground = new SolidColorBrush(Color.FromRgb(0x10, 0xB9, 0x81));
            }
        }

        private void AddFood_Click(object sender, RoutedEventArgs e)
        {
            string name = FoodNameBox.Text.Trim();
            if (string.IsNullOrWhiteSpace(name))
            {
                ShowAddStatus("Enter a food name.", false);
                return;
            }

            if (!int.TryParse(FoodCaloriesBox.Text.Trim(), out int calories) || calories <= 0)
            {
                ShowAddStatus("Enter valid calories (positive number).", false);
                return;
            }

            string meal = ((ComboBoxItem)MealTypeCombo.SelectedItem)?.Content?.ToString() ?? "Breakfast";

            var entry = new FoodEntry
            {
                Name = name,
                Calories = calories,
                Date = DateTime.Today,
                MealType = meal
            };

            var all = _foodService.Load();
            all.Add(entry);
            _foodService.Save(all);

            FoodNameBox.Clear();
            FoodCaloriesBox.Clear();
            ShowAddStatus($"\u2705  {name} ({calories} kcal) added.", true);

            Refresh();
        }

        private void DeleteFood_Click(object sender, RoutedEventArgs e)
        {
            if (sender is not Button btn || btn.Tag is not FoodEntryViewModel vm) return;

            var all = _foodService.Load();
            var match = all.FirstOrDefault(f =>
                f.Name == vm.Name && f.Calories == vm.Calories &&
                f.MealType == vm.MealType && f.Date.Date == vm.Date.Date);

            if (match != null)
            {
                all.Remove(match);
                _foodService.Save(all);
                Refresh();
            }
        }

        private void ShowAddStatus(string message, bool success)
        {
            AddFoodStatusText.Text = message;
            AddFoodStatusText.Foreground = success
                ? new SolidColorBrush(Color.FromRgb(0x10, 0xB9, 0x81))
                : new SolidColorBrush(Color.FromRgb(0xEF, 0x44, 0x44));
            AddFoodStatusText.Visibility = Visibility.Visible;
        }

        private class FoodEntryViewModel
        {
            public string Name { get; }
            public int Calories { get; }
            public string MealType { get; }
            public DateTime Date { get; }
            public string MealTypeColor { get; }
            public string MealTypeTextColor { get; }

            public FoodEntryViewModel(FoodEntry entry)
            {
                Name = entry.Name;
                Calories = entry.Calories;
                MealType = entry.MealType;
                Date = entry.Date;
                (MealTypeColor, MealTypeTextColor) = entry.MealType switch
                {
                    "Breakfast" => ("#FEF3C7", "#92400E"),
                    "Lunch"     => ("#D1FAE5", "#065F46"),
                    "Dinner"    => ("#DBEAFE", "#1E40AF"),
                    _           => ("#F3E8FF", "#6D28D9")   // Snack
                };
            }
        }
    }
}
